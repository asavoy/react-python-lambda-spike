def lambda_handler(event, context):
    return "This is a dummy response from the bootstrap lambda_handler"
